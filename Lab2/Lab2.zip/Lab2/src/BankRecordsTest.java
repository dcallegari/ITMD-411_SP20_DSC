/*	
 * Illinois Institute of Tecnology
 * ITMD-411 -- Lab 2 -- Arrays
 * DANIEL S CALLEGARI, ID A20424597 
 */

public class BankRecordsTest {
	
	//Main class to run program
	public static void main(String args[]) {
		
		//Initialize item
		BankRecords br1 = new BankRecords();
		
		//Start processes
		br1.readData();
		
	}
	
}